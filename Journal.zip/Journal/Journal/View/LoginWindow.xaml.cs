﻿using Journal.ViewModels;
using System;
using System.Windows;

namespace Journal
{
    public partial class LoginWindow : Window
    {
        public LoginWindow()
        {
            InitializeComponent();
        }
        private void Window_Closed(object sender, EventArgs e)
        {
            if (DialogResult == false)
            {
                Application.Current.Shutdown();
            }
        }
        private void checkButton_Click_1(object sender, RoutedEventArgs e)
        {
            if (LoginModelView.IsLogged)
            {
                DialogResult = true;
            }
        }
    }
}
