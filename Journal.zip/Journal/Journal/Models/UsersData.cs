﻿using System;
using System.Linq;

namespace Journal.Models
{
    public class UsersData : Data<User>, IDisposable
    {
        public User? GetAccount(string login)
        {
            return Collection.Where(a => a.Login == login).ToList().FirstOrDefault();
        }

        public bool AddUser(string login, string name, string lastName, string pass)
        {
            if (Collection.Any(a => a.Login == login)) return false;
            Collection.Add(new User(login, name, lastName, pass));
            return true;
        }
        public bool RemoveUser(string login)
        {
            if (!Collection.Any(a => a.Login == login)) return false;
            Collection.Remove((User)Collection.First(a => a.Login == login));
            return true;
        }
        public bool LoginCheck(string login, string password)
        {
            if (GetAccount(login) is not User u) return false;
            return u.Password == password;
        }

    }
}
