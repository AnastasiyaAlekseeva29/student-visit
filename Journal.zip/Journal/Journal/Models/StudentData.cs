﻿using System;
using System.Linq;

namespace Journal.Models
{
    public class StudentData : Data<Student>, IDisposable
    {
        public bool AddStudent(int id, string name, string lastName, string group)
        {
            if (Collection.Any(a => a.Id == id)) return false;
            Collection.Add(new Student(id, name, lastName, group));
            return true;
        }
        public bool RemoveStudent(int id)
        {
            if (!Collection.Any(a => a.Id == id)) return false;
            Collection.Remove((Student)Collection.First(a => a.Id == id));
            return true;
        }
    }
}
