﻿using System;
using System.Linq;

namespace Journal.Models
{
    public class AttendanceData : Data<Attendance>, IDisposable
    {
        public bool AddAttandance(DateOnly date)
        {
            if (Collection.Any(a => a.Date == date)) return false;
            Collection.Add(new Attendance(date));
            return true;
        }
        public bool RemoveAttendance(DateOnly date)
        {
            if (!Collection.Any(a => a.Date == date)) return false;
            Collection.Remove((Attendance)Collection.First(a => a.Date == date));
            return true;
        }
    }
    public enum Reason
    {
        Unknown, Sick
    }
}
