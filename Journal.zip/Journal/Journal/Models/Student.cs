﻿namespace Journal.Models
{
    public class Student : Base
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string LastName { get; set; }
        public string Group { get; set; }
        public Student() { }
        public Student(int id, string name, string lastName, string group)
        {
            Id = id;
            Name = name;
            LastName = lastName;
            Group = group;
        }
    }
}
