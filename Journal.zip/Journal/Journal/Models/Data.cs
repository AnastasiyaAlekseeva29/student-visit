﻿using System;
using System.Collections.ObjectModel;
using System.Globalization;
using System.IO;
using System.Text.Encodings.Web;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Text.Unicode;

namespace Journal.Models
{
    public class Data<T> : IDisposable
    {
        private const string path = "dat/";
        private readonly JsonSerializerOptions options = new()
        {
            WriteIndented = true,
            DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
            Encoder = JavaScriptEncoder.Create(UnicodeRanges.BasicLatin, UnicodeRanges.Cyrillic),
            IncludeFields = false
        };
        public Data()
        {
            Collection = Load();
        }
        public ObservableCollection<T> Collection { get; set; }
        public void Dispose()
        {
            ReleaseUnmanagedResources();
            GC.SuppressFinalize(this);
        }
        ~Data()
        {
            ReleaseUnmanagedResources();
        }
        public void Save()
        {
            try
            {
                var name = GetType().Name;
                Directory.CreateDirectory(path);
                using var fs = new FileStream($"{path}{name}.json", FileMode.Create);
                JsonSerializer.Serialize(fs, Collection, options);
            }
            catch (Exception)
            {
                //
            }
        }
        protected ObservableCollection<T> Load()
        {
            try
            {
                var name = GetType().Name;
                using var fs = new FileStream($"{path}{name}.json", FileMode.OpenOrCreate);
                return JsonSerializer.Deserialize<ObservableCollection<T>>(fs, options)!;
            }
            catch
            {
                return new ObservableCollection<T>();
            }
        }
        protected void ReleaseUnmanagedResources()
        {
            Save();
        }
    }
    public class DateOnlyJsonConverter : JsonConverter<DateOnly>
    {
        private const string Format = "yyyy-MM-dd";

        public override DateOnly Read(ref Utf8JsonReader reader, Type typeToConvert, JsonSerializerOptions options)
        {
            return DateOnly.ParseExact(reader.GetString()!, Format, CultureInfo.InvariantCulture);
        }

        public override void Write(Utf8JsonWriter writer, DateOnly value, JsonSerializerOptions options)
        {
            writer.WriteStringValue(value.ToString(Format, CultureInfo.InvariantCulture));
        }
    }
}
