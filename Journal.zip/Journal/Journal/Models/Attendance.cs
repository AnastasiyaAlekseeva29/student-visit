﻿using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Journal.Models
{
    public class Attendance : Base
    {
        [JsonConverter(typeof(DateOnlyJsonConverter))]
        public DateOnly Date { get; set; }
        public Dictionary<int, Reason> Students { get; set; }
        public Attendance() { }
        public Attendance(DateOnly date)
        {
            Date = date;
            Students = new Dictionary<int, Reason>();
        }
    }
}
