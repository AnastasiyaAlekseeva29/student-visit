﻿using Journal.Models;
using Journal.View;
using System.Linq;

namespace Journal.ViewModels
{
    internal class EditStudentModelView : Base
    {
        public string NewStudentName { get; set; }
        public string NewStudentLastName { get; set; }
        public string NewStudentGroup { get; set; }
        public RelayCommand AddStudent { get; }
        public RelayCommand DeleteStudent { get; }
        public RelayCommand Exit { get; }
        private int Id
        {
            get
            {
                return MainViewModel.StudentData.Collection.Max(a => a.Id) + 1;
            }
        }
        public EditStudentModelView()
        {
            AddStudent = new RelayCommand(AddStudentClick);
            DeleteStudent = new RelayCommand(DeleteStudentClick);
            Exit = new RelayCommand(ExitClick);
        }

        private void AddStudentClick(object o)
        {
            MainViewModel.StudentData.AddStudent(Id, NewStudentName, NewStudentLastName, NewStudentGroup);
        }
        private void DeleteStudentClick(object sender)
        {
            try
            {
                var st = (Student)sender;
                MainViewModel.StudentData.RemoveStudent(st.Id);
            }
            catch
            {
                //
            }
        }
        private void ExitClick(object sender)
        {
            MainViewModel.StudentData.Save();
            var win = (EditStudentsWindow)sender;
            win.Close();
        }
    }
}
