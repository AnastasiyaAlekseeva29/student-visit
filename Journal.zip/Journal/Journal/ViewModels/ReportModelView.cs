﻿using Journal.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;

namespace Journal.ViewModels
{
    public class ReportModelView : Base
    {
        public DataTable ReportData { get; set; }
        public ReportModelView()
        {
            GenerateReportData();
        }
        public void GenerateReportData()
        {
            DataRow row;
            ReportData = new DataTable();

            ReportData.Columns.Add("Прізвище та ім'я", typeof(string));
            ReportData.Columns.Add("Група", typeof(string));
            ReportData.Columns.Add("К-ть прогулів", typeof(int));
            ReportData.Columns.Add("% відвідування", typeof(string));

            List<int> ids = new List<int>();
            foreach (Attendance att in MainViewModel.AttendanceData.Collection)
            {
                foreach (KeyValuePair<int, Reason> s in att.Students)
                {
                    ids.Add(s.Key);
                }
            }

            foreach (Student student in MainViewModel.StudentData.Collection)
            {
                row = ReportData.NewRow();
                row["Прізвище та ім'я"] = (student.LastName + " " + student.Name).ToString();
                row["Група"] = student.Group;
                int quantity = ids.Where(a => a == student.Id).Count();
                row["К-ть прогулів"] = quantity;
                double perc = 100 - Convert.ToDouble(quantity) / Convert.ToDouble(MainViewModel.AttendanceData.Collection.Count) * 100;
                row["% відвідування"] = Math.Round(perc, 1).ToString() + "%";
                ReportData.Rows.Add(row);
            }
        }
    }
}
