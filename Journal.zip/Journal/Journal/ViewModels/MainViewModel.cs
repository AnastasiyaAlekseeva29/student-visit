﻿using Journal.Models;
using Journal.View;
using System;
using System.Collections.Generic;
using System.Data;
using System.Windows.Controls;

namespace Journal.ViewModels
{
    public class MainViewModel : Base, IDisposable
    {
        public static StudentData StudentData { get; set; } = new StudentData();
        public static AttendanceData AttendanceData { get; set; } = new AttendanceData();
        public static UsersData UserData { get; set; } = new UsersData();
        public DataTable FullData { get; set; } = new DataTable();
        public RelayCommand EditStudents { get; }
        public RelayCommand EditUsers { get; }
        public RelayCommand EditDate { get; }
        public RelayCommand SaveFullDataCommand { get; }
        public RelayCommand FillFullDataCommand { get; }
        public RelayCommand ReportCommand { get; }

        public MainViewModel()
        {
            EditStudents = new RelayCommand(EditStudentsClick);
            EditUsers = new RelayCommand(EditUsersClick);
            EditDate = new RelayCommand(EditDateClick);
            SaveFullDataCommand = new RelayCommand(SaveFullDataClick);
            FillFullDataCommand = new RelayCommand(FillFullDataClick);
            ReportCommand = new RelayCommand(ReportClick);
            FillFullData();
        }
        private void FillFullData()
        {
            FullData = new DataTable();
            DataRow row;

            FullData.Columns.Add("ID", typeof(int));
            FullData.Columns.Add("Прізвище та ім'я", typeof(string));
            FullData.Columns.Add("Група", typeof(string));
            foreach (Attendance a in AttendanceData.Collection)
            {
                DataColumn dataColumn = new DataColumn();
                dataColumn.ColumnName = a.Date.Day.ToString() + "-" + a.Date.Month.ToString();
                dataColumn.DataType = typeof(string);
                FullData.Columns.Add(dataColumn);
            }

            foreach (Student s in StudentData.Collection)
            {
                row = FullData.NewRow();
                row["ID"] = s.Id;
                row["Прізвище та ім'я"] = s.LastName + " " + s.Name;
                row["Група"] = s.Group;
                foreach (Attendance a in AttendanceData.Collection)
                {
                    foreach (KeyValuePair<int, Reason> k in a.Students)
                    {
                        if (s.Id == k.Key)
                        {
                            if (k.Value == Reason.Unknown)
                            {
                                row[a.Date.Day.ToString() + "-" + a.Date.Month.ToString()] = "н";
                            }
                            else if (k.Value == Reason.Sick)
                            {
                                row[a.Date.Day.ToString() + "-" + a.Date.Month.ToString()] = "хв";
                            }
                        }
                    }
                }
                FullData.Rows.Add(row);
            }
        }
        private void SaveFullData()
        {
            AttendanceData.Collection.Clear();
            string[] str;

            for (int j = 3; j < FullData.Columns.Count; j++)
            {
                str = FullData.Columns[j].ColumnName.Split("-");
                DateOnly date = new DateOnly(DateTime.Now.Year, Int32.Parse(str[1]), Int32.Parse(str[0]));
                Attendance att = new Attendance(date);

                for (int i = 0; i < FullData.Rows.Count; i++)
                {
                    if (FullData.Rows[i].Field<string>(j) == "н")
                    {
                        att.Students.Add(FullData.Rows[i].Field<int>("ID"), Reason.Unknown);
                    }
                    else if (FullData.Rows[i].Field<string>(j) == "хв")
                    {
                        att.Students.Add(FullData.Rows[i].Field<int>("ID"), Reason.Sick);
                    }
                }
                AttendanceData.Collection.Add(att);
            }
        }
        private void EditStudentsClick(object o)
        {
            new EditStudentsWindow().ShowDialog();
        }
        private void EditUsersClick(object o)
        {
            new EditUserWindow().ShowDialog();
        }
        private void EditDateClick(object o)
        {
            new EditDateWindow().ShowDialog();
        }
        private void ReportClick(object o)
        {
            new ReportWindow().ShowDialog();
        }
        private void SaveFullDataClick(object sender)
        {
            SaveFullData();
            AttendanceData.Save();
        }
        private void FillFullDataClick(object sender)
        {
            FillFullData();
            var obj = (DataGrid)sender;
            obj.ItemsSource = null;
            obj.ItemsSource = FullData.DefaultView;
        }
        public void Dispose()
        {
            ReleaseUnmanagedResources();
            GC.SuppressFinalize(this);
        }
        ~MainViewModel()
        {
            ReleaseUnmanagedResources();
        }
        private void ReleaseUnmanagedResources()
        {
            StudentData.Dispose();
            UserData.Dispose();
            AttendanceData.Dispose();
        }

    }
}
