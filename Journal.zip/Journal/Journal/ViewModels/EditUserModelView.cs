﻿using Journal.Models;
using Journal.View;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Journal.ViewModels
{
    class EditUserModelView : Base
    {
        public string NewLogin { get; set; }
        public string NewPassword { get; set; }
        public string NewName { get; set; }
        public string NewLastName { get; set; }
        public RelayCommand AddUser { get; }
        public RelayCommand DeleteUser { get; }
        public RelayCommand Exit { get; }
        public EditUserModelView()
        {
            AddUser = new RelayCommand(AddUserClick);
            DeleteUser = new RelayCommand(DeleteUserClick);
            Exit = new RelayCommand(ExitClick);
        }

        private void AddUserClick(object o)
        {
            MainViewModel.UserData.AddUser(NewLogin, NewName, NewLastName, NewPassword);
        }
        private void DeleteUserClick(object sender)
        {
            try
            {
                var st = (User)sender;
                MainViewModel.UserData.RemoveUser(st.Login);
            }
            catch
            {
                //
            }
        }
        private void ExitClick(object sender)
        {
            MainViewModel.UserData.Save();
            var win = (EditUserWindow)sender;
            win.Close();
        }
    }
}
