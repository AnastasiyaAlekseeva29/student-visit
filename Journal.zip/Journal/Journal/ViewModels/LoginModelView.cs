﻿using Journal.Models;
using System.Windows;
using System.Windows.Controls;

namespace Journal.ViewModels
{
    public class LoginModelView : Base
    {
        public string UserLogin { get; set; }
        public string Password { get; set; }
        public RelayCommand LogCommand { get; }
        public static bool IsLogged { get; set; }
        public LoginModelView()
        {
            LogCommand = new RelayCommand(LogCommandClick);
        }
        private void LogCommandClick(object sender)
        {
            var pasBox = (PasswordBox)sender;
            Password = pasBox.Password;
            IsLogged = MainViewModel.UserData.LoginCheck(UserLogin, Password);
            if (!IsLogged)
            {
                MessageBox.Show("Невірний логін або пароль.");
            }
        }
    }
}
