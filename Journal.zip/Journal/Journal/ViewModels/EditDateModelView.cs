﻿using Journal.Models;
using Journal.View;
using System;

namespace Journal.ViewModels
{
    class EditDateModelView : Base
    {
        public DateTime NewDate { get; set; }
        public RelayCommand AddDate { get; }
        public RelayCommand DeleteDate { get; }
        public RelayCommand Exit { get; }
        public EditDateModelView()
        {
            AddDate = new RelayCommand(AddDateClick);
            DeleteDate = new RelayCommand(DeleteDateClick);
            Exit = new RelayCommand(ExitClick);
            NewDate = DateTime.Now;
        }

        private void AddDateClick(object o)
        {
            MainViewModel.AttendanceData.AddAttandance(new DateOnly(NewDate.Year, NewDate.Month, NewDate.Day));
        }
        private void DeleteDateClick(object sender)
        {
            try
            {
                var st = (Attendance)sender;
                MainViewModel.AttendanceData.RemoveAttendance(st.Date);
            }
            catch
            {
                //
            }
        }
        private void ExitClick(object sender)
        {
            MainViewModel.AttendanceData.Save();
            var win = (EditDateWindow)sender;
            win.Close();
        }
    }
}
